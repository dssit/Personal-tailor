 		$('.qrcode').hover(
			function(){$("#qrcode").css('display','block')}, //鼠标移入
			function(){$('#qrcode').css('display','none')} //鼠标移出
		);

	