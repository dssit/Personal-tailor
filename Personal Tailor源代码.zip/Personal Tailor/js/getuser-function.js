	
var username= localStorage.getItem("username");
	
	
	if(username===null){
		$(".a111").text();

		$(".a111").click(function(){
   			 window.open(src="login.html");
		});

		$(".myInfo").click(function(){
		 alert("你还没有登入！请前往登入！");
		 })
		$(".a121").click(function(){
		  alert("你还没有登入！请前往登入！");	
		 })
		$(".Person-tailor").click(function(){
		 alert("你还没有登入！请前往登入！");
		 })

 	}else{
 		$(".a111").html("欢迎！"+username);
		// localStorage.removeItem("username");

		// $(".a111").html("欢迎！"+username);
		// localStorage.removeItem("username");
		$(".a111").click(function(){
		 		alert("你已经登入成功了！");
		 })
		$(".myInfo").click(function(){
		 	window.open(src="myInfo.html");
		 })
		$(".a121").click(function(){
		 	window.open(src="shop.html");
		 })
		$(".Person-tailor").click(function(){
		 	window.open(src="custom.html");
		 })
	}
