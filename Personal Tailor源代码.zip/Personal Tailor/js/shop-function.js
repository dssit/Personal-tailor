   $(".add").click(function(){
		// alert($(this).prev().val());
		var a=($(this).prev().val());
	    b=parseInt(a)+1;
	    console.log(b);
		  // $(".Tx").val().var("")
	    $(this).prev().val(b);  
	    sumprice();
	})
	$(".sub").click(function(){
		// alert($(this).next().val());
		var a=($(this).next().val());
	     b=parseInt(a)-1;
	     if(b<=1){
	     	b=1;
	     }
	    console.log(b);
	   $(this).next().val(b);
	   sumprice();  
	})

// 加减功能



$(".checkboxall").click(function(){
	var a=$(".checkboxall").prop("checked");
	if(a){
		$(".a").prop("checked",true);
	}else{ 
		$(".a").prop("checked",false);
	}
	sumprice();
})


$(".a").click(function(){
	var a=$(".a").length;
	var b=$(".a","checked").length;
	if(a==b){
		$(".checkboxall").prop("checked",true);
	}else{
		$(".checkboxall").prop("checked",false);
	}
	 sumprice();
})




// 全选功能


// 商品删除功能
$(".de").click(function(){
	$(this).parents(".gooddiv").remove();
	 sumprice();
})


//计算总价的函数功能
function sumprice(){
	sum=0;
	$(".a:checked").each(function(){
		var price= parseInt($(this).parents(".gooddiv").find(".pr").attr("jiage"));
		console.log($(".pr").attr("jiage"));
		var num=parseInt($(this).parents(".gooddiv").find(".Tx").val());
		console.log(price);
		console.log(num);
		sum=sum+price*num;
	})
	$(".sumtext").text(sum+"元");

}

