       	$('li').hover(
			function(){$(this).css('color','red')}, //鼠标移入
			function(){$(this).css('color','#fff')} //鼠标移出
		);

		$('.foot-left').hover(
			function(){$(this).css('background-color','#8B0000')}, //鼠标移入
			function(){$(this).css('background-color','red')} //鼠标移出
		);