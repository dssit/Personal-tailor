var mySwiper = new Swiper('.swiper-container',{
autoplay:5000,
// watchSlidesProgress : true,
watchSlidesVisibility : false,
loop : true,
effect : 'coverflow',
slidesPerView: 3,
centeredSlides: true,
})

setInterval("mySwiper.slidePrev()", 3000);