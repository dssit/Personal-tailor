$(".picture").click(function(){
	$("#bt").click();
})

$("#bt").change(function(){
var MyTest = document.getElementById("bt").files[0];
  var reader = new FileReader();
  reader.readAsDataURL(MyTest);
  reader.onload = function(theFile) {
  var image = new Image();
  image.src = theFile.target.result;
   $(".picture").attr('src',image.src);
 };

});

