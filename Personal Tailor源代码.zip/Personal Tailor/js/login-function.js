
							$(".a111").click(function(){
							//登入界面 
								$(".login").show();
							
							});
							$(".but-close").click(function(){
								$(".login").hide();
							});

							$("#sp2").click(function(){
								$(".login_2").hide();
								$(".sign_in_2").show();
							})
							$("#sp1").click(function(){
								$(".login_2").show();
								$(".sign_in_2").hide();
							})
						

							var a=true;
							var b=true;
							var c=true;
		
							function login(){
								var username=$(".input3").val();
		    					if(!username){
		    						$(".tishi3").text("账号不能为空");
		    							$(".tishi3").show();
		        					a=false;
		    					}else{
		    						if(username.length>16||username.length<6){
		    	
		    							$(".tishi3").text("账号长度不正确");
		    								$(".tishi3").show();
		    	    					a=false; 
		    						}else{ 
		    							$(".tishi3").text("");
		    	    					a=true;
		    						     }
		    						}	    
							}
							function checkpassword(){
								var password=$(".input4").val();
									if(!password){
		    							$(".tishi4").text("密码不能为空");
		    							$(".tishi4").show();
		        						b=false;
		   							}else{
		    							if(password.length>16||password.length<6){	    		
		    								$(".tishi4").text("密码长度不正确");
		    								$(".tishi4").show();
		    	    						b=false;
		    							}else{
		    								$(".tishi4").text("");
		    	    						b=true;
		    								}
		    							}
		    		
							}

		
							$(".input3").blur(function(){
									login();
								
							})
								
							$(".input4").blur(function(){
								checkpassword();
							})
								
	        			
							$(".sign_in_but").click(function(){
								var a=true;
								var username=$(".input3").val();
								if(!username){
							    	$(".tishi3").text("账号不能为空");
							    	$(".tishi3").show();
							        a=false;
							    }else{
							    	if(username.length>16||username.length<6){
							    		
							    		$(".tishi3").text("账号长度不正确");
							    		$(".tishi3").show();
							    	    a=false; 
							    	}else{

							    		$(".tishi3").text("");
							    		$(".tishi3").show();
							    	    a=true;
							    	}
							    }
							
								checkpassword();
								console.log(a);
								console.log(b);
								if(a&&b){
									
						        	var username=$(".input3").val();
								    var password=$(".input4").val();
							    	
							    	var myuser={'username':username,'password':password};
					              	
						        	var result=true;
									
						        	var user=localStorage.user;

						        	if(user){	
						        		user=JSON.parse(user);
						        		console.log(username);
						        		for(var a=0;a<user.length;a++){
						        			if(user[a].username==username){
						        				result=false;
						        			}
						        		}
						        		
						        		if(result){
						        			user.push(myuser);
						        			localStorage.user=JSON.stringify(user);
						        			alert("注册成功");
						        		}else{
						        			alert("此账号已经注册了");
						        		}
						        	}else{
						        		user=new Array();
						        		user.push(myuser);
						        		console.log(user);
						        		localStorage.user=JSON.stringify(user);
						        		alert("注册成功");
						        	}
								}
							})	


	// 登入
						$(".login_in_but").click(function(){	  

								var a=true;
								
								var username=$(".input1").val();
								if(!username){
							    	$(".tishi1").text("账号不能为空");
							    	$(".tishi1").show();
							        a=false;
							    }else{
							    	if(username.length>16||username.length<6){
							    		
							    		$(".tishi1").text("账号长度不正确");
							    		$(".tishi1").show();
							    	    a=false; 
							    	}else{

							    		$(".tishi1").text("");
							    		$(".tishi1").show();
							    	    a=true;
							    	}
							    }
							
			// repassword();

								function checkpassword1(){
									var password=$(".input2").val();
									if(!password){	
								    	$(".tishi21").text("密码不能为空");
								    	$(".tishi21").show();
								        b=false;
								    }else{
								    	if(password.length>16||password.length<6){	    		
								    		$(".tishi21").text("密码长度不正确");
								    		$(".tishi21").show();
								    	    b=false;
								    	}else{
								    			
								    		$(".tishi21").text("");
								    	    b=true;
								    	}
								    }
							    }

								   	checkpassword1();					
									console.log(a);
									console.log(b);
									if(a&&b){
										
							        	var username=$(".input1").val();
									    var password=$(".input2").val();
								    	
								    	var myuser={'username':username,'password':password};
						              	
							        	var c=false;
										var d=false;
							        	var user=localStorage.user;


							        	if(user){	
							        		user=JSON.parse(user);
							        		console.log(username);
							        		for(var a=0;a<user.length;a++){
							        			if(user[a].username==username){
							        				c=true;
							        			}
							        		}
							        		

							        		for(var a=0;a<user.length;a++){
							        			if(user[a].password==password){
							        				d=true;
							        			}
							        		}

							        		if(c&&d){
							        			// user.push(myuser);
							        			localStorage.user=JSON.stringify(user);
							        			console.log(username);
							        			localStorage.setItem("username",username);
							        			alert("登入成功");
							        			// localStorage.setItem("username",JSON.stringify(user));
							        			window.location.href="../index.html";
							        			//实现了页面跳转功能。 		
							        		}else{
							        			alert("没有这个账号！");
							        		}
							        	
							       		 }
							       	 	
							        	
									}
								
							})

						