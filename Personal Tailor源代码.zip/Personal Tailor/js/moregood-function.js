var  page =0;
			$(document).scroll(function(){
				var	docuheight=document.documentElement.scrollTop;
				var	windownheight=document.documentElement.clientHeight;
				var	scrollHeight=document.documentElement.scrollHeight;
				if(scrollHeight>300){
					$(".xq").show();
				  	}else{
					$(".xq").hide();
				   }
				if(docuheight+windownheight>scrollHeight-5){					
		//		$(".shop_box").append('<div class="shop">'
		//	+'<img src="image/1.png" class="shop_img"/>'
		//	+'<div class="a">￥256.00</div>'
		//+'</div>'+'<div class="shop">'
		//	+'<img src="image/2.png" class="shop_img"/>'
		//	+'<div class="a">￥255.00</div>'
		//+'</div>'+'<div class="shop">'
		//	+'<img src="image/3.png" class="shop_img"/>'
		//	+'<div class="a">￥250.00</div>'
		//+'</div>'+'<div class="shop">'
		//	+'<img src="image/4.png" class="shop_img"/>'
		//	+'<div class="a">￥250.00</div>'
		//+'</div>'+'<div class="shop">'
		//	+'<img src="image/5.png" class="shop_img"/>'
		//	+'<div class="a">￥250.00</div>'
		//+'</div>'+'<div class="shop">'
		//	+'<img src="image/6.png" class="shop_img"/>'
		//	+'<div class="a">￥256.00</div>'
		//+'</div>')
// 				page++;
// 		$.ajax({
// 			type:"post",
// 			url:"php/shuju.php", 
// 			asyn:true,
// 			data:'page='+page+'&pagenum=4', 
// 			dataType:'json',
// 			success:function(data){
// 					console.log(data.result);
// 				if(data.result=='seccuss'){
// 					console.log("ok");
// 					$.each(data.list,function(k,v){
// 						$(".shop_box").append('<div class="shop">'
// 						+'<img src="'+v.img+'" class="shop_img"/>'
// 						+'<div class="a">'+v.price+'</div>'
// 					+'</div>'
// 						) 
// 					})
// 				}else if(data.result=='error'){

// 				}
// 			}
// 		})
			}
			})

// $(".but").click(function(){
		
// })
// 		$(document).delegate(".shop","click",function(){
// 			alert(111);
// 		})



				$(".xq").click(function(){
					$("html").animate({scrollTop:0},1000);//当点击这个时，会在1s之内返页面到top处
				})

				$(".xq").click(function(){
					// $(".shop_box").emptyClass();//使它为空,但是div不会消失。
					// $(".shop_box").removeClass("active"); //div消失。
					$(".shop_box").addClass("active");//为他们添加class属性。
				})


				$(".xq").click(function(){
					if ($(".shop_box").hasClass("active")){
					}else{
					}

				})



				$(".but").click(function(){
				 	  yangalert("注册失败！");

				});

				function yangalert(text){
					$(".yang span").text(text);
					$(".yang").fadeIn(500);
					clearTimeout(A);
				var A=setTimeout(function(){
					$(".yang").fadeOut(500);
				  },2000)
			}
