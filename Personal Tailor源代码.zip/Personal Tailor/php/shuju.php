<?php
   
   $pagenum=$_POST['pagenum'];
   $page=$_POST['page'];
   
   
   $list=array();
   $list[0]['title']='苹果电脑';
   $list[0]['price']='398';
   $list[0]['num']='10';
   $list[0]['img']='image/1.png';
   $list[1]['title']='三级手机';
   $list[1]['price']='398';
   $list[1]['num']='10';
   $list[1]['img']='image/2.png';
   $list[2]['title']='苹果手机';
   $list[2]['price']='398';
   $list[2]['num']='10';
   $list[2]['img']='image/1.png';
   $list[3]['title']='苹果手机';
   $list[3]['price']='398';
   $list[3]['num']='10';
   $list[3]['img']='image/4.png';
   $list[4]['title']='苹果手机';
   $list[4]['price']='398';
   $list[4]['num']='10';
   $list[4]['img']='image/5.png';
   $list[5]['title']='苹果手机';
   $list[5]['price']='398';
   $list[5]['num']='10';
   $list[5]['img']='image/6.png';
   $list[6]['title']='苹果手机';
   $list[6]['price']='398';
   $list[6]['num']='10';
   $list[6]['img']='image/1.png';
   
   
   

   $result=array();
   $num=0;
   foreach($list as $k=>$v){
   	  if($pagenum*($page-1)<=$k&&$k<$pagenum*$page){
   	  	$result[$num]=$v;
   	  	$num++;
   	  }
   }
   
   if(count($result)>0){
   	  $data['result']='seccuss';
   	  $data['list']=$result;
   }else{
   	  $data['result']='error';
   }
   
   echo json_encode($data);
  
?>